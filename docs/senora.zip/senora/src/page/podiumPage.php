<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<meta name="author" content="Mushimu">
<meta name="keywords" content="HTML, CSS, XML, XHTML, JavaScript, Facebook">
<meta name="description" content="Break The Silence Facebook App">

<!--
<link rel="stylesheet" type="text/css" href="stylesheet/style.css" />

<script type="text/javascript" src="javascript/jquery.js"></script>
<script type="text/javascript" src="javascript/bjqs-1.3.min.js"></script>
<script type='text/javascript' src='javascript/jquery.simplemodal.js'></script>
<script type="text/javascript" src="javascript/webpers.js"></script>
<script src="javascript/class2_slide.js" type="text/javascript"></script>-->
<!-- 
	font-family: 'Noto Sans', sans-serif;
-->
<style type="text/css">
div#overlay {
display: none;
z-index: 2;
background: #000;
position: fixed;
width: 100%;
height: 100%;
top: 0px;
left: 0px;
text-align: center;
opacity: 0.8;
}
div#specialBox {
display: none;
position: relative;
z-index: 3;
margin: 150px auto 0px auto;
width: 500px; 
height: 300px;
background: #FFF;
color: #000;
 }
div#wrapper {
position:absolute;
top: 0px;
left: 20%;
padding-left:24px;
  }
     
</style>


  <script type="text/javascript"src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.0/jquery.min.js"></script>
    <script type="text/javascript" src="js/jquery.cookie.js"></script>
    <script type="text/javascript">                                         
    $(document).ready(function() {
        if( $.cookie('showOnlyOne') ){
            //it is still within the day
            //hide the div
           $('#overlay').hide();
          $('#specialBox').hide();
        } else {
            //either cookie already expired, or user never visit the site
            //create the cookie
            $.cookie('showOnlyOne', 'showOnlyOne', { expires: 1 });

            //and display the div
          $('#overlay').show();
          $('#specialBox').show();
          $('#specialBox').delay(3200).fadeOut(300);
          $('#overlay').delay(3200).fadeOut(300);
        }
    });
    </script>

<title>Podium Page</title>
</head>
<body>
<!-- Start Overlay -->
 <div id="overlay"></div>
 <!-- End Overlay -->
 <!-- Start Special Centered Box -->
 <div id="specialBox">

 TEST Overlay BOX

 </div>

 <!-- Start Special Centered Box -->
  <!-- Start Normal Page Content -->

 <div id="wrapper">        

 Hello World!

 </div>
	
</body>
</html>
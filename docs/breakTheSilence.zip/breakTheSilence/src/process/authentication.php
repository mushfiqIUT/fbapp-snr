<?php
/**
 * @author: imon
 * @since: 1/12/14 7:44 PM
 */

$sitebasepath = $_SERVER['DOCUMENT_ROOT'];

require("$sitebasepath/breakTheSilence/src/process/fbConfig.php");
require("$sitebasepath/breakTheSilence/src/db/DBConnection.php");

$config = array(
    'appId' => '624830547552783',
    'secret' => 'dc316428a4836477815b3498d8c4fe72',
    'fileUpload' => true,
    'cookie' => true
);

$facebook = new Facebook($config);

$user = null;
$user = $facebook->getUser();

if (isset($_GET['error']) == 'access_denied') {
    echo "<script type='text/javascript'>top.location.href = 'https://www.facebook.com/mushimoApp';</script>";
    exit;
}

if (isset($_GET['request_ids'])) {
    
    $request_ids = ($_GET['request_ids']);
    $arr = explode(",", $request_ids, 2);
    $request_ids = $arr[0];
    //$request_ids =  substr($request_ids, 0, strpos($request_ids, ','));  //list($request_ids) = explode(',', $request_ids);

}

if (isset($_GET['requestId'])) {
    $requestId = $_GET['requestId'];
}
$params = array(
    'scope' => 'email,publish_stream,photo_upload,user_birthday,user_location,user_likes',
    'redirect_uri' => "https://apps.facebook.com/breakTheSilence/index.php?requestId=$request_ids"
);

$loginUrl = $facebook->getLoginUrl($params);

if ($user) {
    //TODO: query in db if user id already exists

    try {
        $user_profile = $facebook->api('/me');

        $id = $user_profile['id'];
        $name = $user_profile['name'];
        $gender = $user_profile['gender'];
        $birthday = $user_profile['birthday'];
        $email = $user_profile['email'];
        $location = $user_profile['location']['name'];

        //TODO: save user info in db

    } catch (FacebookApiException $e) {
        error_log($e);
        $user = null;
    }

    $logoutUrl = $facebook->getLogoutUrl();
}

if (!$user) {
    echo "<script type='text/javascript'>top.location.href = '$loginUrl';</script>";
    exit;
} else {

    $sql = "SELECT fb_id FROM bts_user WHERE fb_id =$id";
    $result = mysql_query($sql);

    if (mysql_num_rows($result) < 1) {

        $currentTimestamp = time();
        $bdtime = strtotime("+12 hours", $currentTimestamp);
        $joinTime = date("Y-m-d H:i:s", $bdtime);

        $insertsql = "INSERT INTO bts_user (fb_id, user_name, gender, date_of_birth, user_email, user_location, user_join_time, request_id) VALUES ('$id', '$name', '$gender', '$birthday', '$email', '$location', '$joinTime', '$requestId')";


        mysql_query($insertsql);
    }
}
?>
<?php

$sitebasepath = $_SERVER['DOCUMENT_ROOT'];

require("$sitebasepath/breakTheSilence/src/process/authentication.php");

if ($user) {
    try {

        $likes_page = $facebook->api("/me/likes/1396002910653043/"); //page id for like

        if (empty($likes_page['data'])) {
            ?>
            <script type="text/javascript">
                window.top.location.href = "https://apps.facebook.com/breakthesilence/src/page/likepage.php";
            </script>
            <?php
            //header('location: src/page/likepage.php');
        }

        $sql_getStatus = "SELECT status,isPost FROM bts_userStat WHERE fb_id = " . $id;
        $result_getStatus = mysql_query($sql_getStatus);
        $result_getStatus = mysql_fetch_array($result_getStatus);
        $statusValue = $result_getStatus['status'];
        $isPost = $result_getStatus['isPost'];

        if ($statusValue == 0 || $statusValue == 1) {
            ?>
            <script type="text/javascript">
                window.top.location.href = "https://apps.facebook.com/breakthesilence/src/page/podiumPage.php";
            </script>
            <?php
            //header('location: src/page/thankYouPage.php');
        } 
        
        if ($isPost == 0) {
        	$publishStream = $facebook->api("/me/feed", 'post', array( 
	        		'message' =>'This is a test for my 1st fb app', 
	        		'link' =>'https://www.facebook.com/mushimoApp', 
	        		'caption' => 'Test post', 
	        		'picture' => "", 
	        		'name' => 'Test by Mushimo', 
	        		'description'=> 'Do not click here !!' ) 
        		);
        		
        	$sql_updatePostStatus = "UPDATE bts_userStat SET isPost = 1 WHERE fb_id = ".$id; 
        	mysql_query($sql_updatePostStatus); 
        }


    } catch (FacebookApiException $e) {
        error_log($e);
        $user = null;
    }

}

?>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

    <meta content="text/html; charset=utf-8" http-equiv="Content-Type"/>
    <meta name="author" content="Mushimu">
    <meta name="keywords" content="HTML, CSS, XML, XHTML, JavaScript, Facebook">
    <meta name="description" content="Break The Silence Facebook App">

    <title>Thank you</title>
</head>
<body>
<div id="fb-root"></div>
<script type="text/javascript" src="https://connect.facebook.net/en_US/all.js"></script>
<script type="text/javascript" src='../js/jquery-2.0.3.min.js'></script>
<script type="text/javascript">
    FB.init({
        appId: '624830547552783',
        status: true,
        cookie: true,
        xfbml: true
    });
    window.fbAsyncInit = function () {
        FB.Canvas.setAutoGrow();
    };
    FB.Canvas.scrollTo(0, 0);
    (function (d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) return;
        js = d.createElement(s);
        js.id = id;
        js.src = "//connect.facebook.net/en_US/all.js#xfbml=1";
        fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));

    function sendInvitation() {
        FB.ui({method: 'apprequests',
            message: 'Click to raise your voice against cervical cancel'
        }, requestCallback);
    }

    function requestCallback(response) {
        if (response.request && response.to) {
            var requestId = response.request;
            var toIdCount = response.to.length;

            $.post('handleInvitation.php', {uid: <?php echo $id?>, requestId: requestId, toIdCount: toIdCount});

            var requestObj = response.request;
            var to = response.to;
            var table = '<table><tbody><tr><td>' + requestObj + '</td></tr><tr><td>' + to + '</td></tr></tbody></table>';
            $("#show").html(table);
        }
    }

</script>

<div>
    Thank you <?php echo $name . ' : ' . $id ?>  for speaking out.
    You and the others like you make the world a safer place
</div>
<div>
    <a href="#" onClick="sendInvitation();">
        <button class="button" style="float:right; margin-left:5px;">Invite</button>
    </a>
</div>

</body>
</html>
<?php
/**
 * @author: imon
 * @since: 1/18/14 6:20 PM
 */
$sitebasepath = $_SERVER['DOCUMENT_ROOT'];

require("$sitebasepath/breakTheSilence/src/db/DBConnection.php");

if (isset($_POST['uid']) && isset($_POST['requestId']) && isset($_POST['toIdCount'])) {

    $uid = mysql_real_escape_string($_POST['uid']);
    $requestId = mysql_real_escape_string($_POST['requestId']);
    $toIdCount = $_POST['toIdCount'];

    mysql_query("INSERT INTO bts_fb_requests (fb_user_id, request_id) VALUES ('$uid', $requestId)")
    or die("MySQL Error: " . mysql_error());
    $result = mysql_query("SELECT no_of_share FROM bts_userStat WHERE fb_id='$uid'");
    $row = mysql_fetch_array($result);
    $currentShareCount = (int)$row['no_of_share'];
    $updatedCount = $currentShareCount + $toIdCount;
    mysql_query("UPDATE bts_userStat SET no_of_share='$updatedCount' WHERE fb_id='$uid'");

}

if (isset($_POST['uid']) && isset($_POST['status']) == '2') {

    $uid = mysql_real_escape_string($_POST['uid']);

    $sql_updateStatus = "UPDATE bts_userStat SET status = 2 WHERE fb_id =$uid";
    mysql_query($sql_updateStatus);

    $result1 = mysql_query("SELECT total_count FROM bts_info WHERE table_id =1");
    $row1 = mysql_fetch_array($result1);
    $currentTotalCount = (int)$row1['total_count'];
    $updatedTotalCount = $currentTotalCount + 1;
    $sql = "UPDATE bts_info SET total_count = $updatedTotalCount WHERE table_id =1";
    mysql_query($sql);

    $request_id = mysql_query("SELECT request_id FROM bts_user WHERE fb_id =$uid");
    $request_id = mysql_fetch_array($request_id);
    $request_id = $request_id['request_id'];

    if ($request_id) {
        $friendId = mysql_query("SELECT fb_user_id FROM bts_fb_requests WHERE request_id=$request_id");
        $friendId = mysql_fetch_array($friendId);
        $friendId = $friendId['fb_user_id'];
        mysql_query("UPDATE bts_userStat SET no_of_acceptance = no_of_acceptance + 1 WHERE fb_id =$friendId");
    }
}
?>
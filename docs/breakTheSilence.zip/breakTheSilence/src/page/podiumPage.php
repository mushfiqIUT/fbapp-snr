<?php

$sitebasepath = $_SERVER['DOCUMENT_ROOT'];

require("$sitebasepath/breakTheSilence/src/process/authentication.php");

if ($user) {

    try {

        $likes_page = $facebook->api("/me/likes/1396002910653043/"); //page id for like 

        if (empty($likes_page['data'])) {
            ?>
            <script type="text/javascript">
                window.top.location.href = "https://apps.facebook.com/breakthesilence/src/page/likepage.php";
            </script>
            <?php
            //header('location: src/page/likepage.php');
        }

        $sql_getStatus = "SELECT status FROM bts_userStat WHERE fb_id = " . $id;
        $result_getStatus = mysql_query($sql_getStatus);
        $result_getStatus = mysql_fetch_array($result_getStatus);
        $statusValue = $result_getStatus['status'];

        if ($statusValue == 2) {
            ?>
            <script type="text/javascript">
                window.top.location.href = "https://apps.facebook.com/breakthesilence/src/page/thankYouPage.php";
            </script>
            <?php
            //header('location: src/page/thankYouPage.php');
        } elseif ($statusValue == 0) {
            $sql_updateStatus = "UPDATE bts_userStat
                     SET status = 1
                     WHERE fb_id =" . $id;
            mysql_query($sql_updateStatus);
        }
        
        //checking current total count
        
        $totalCount = mysql_query("SELECT total_count FROM bts_info WHERE table_id =1");
    	$totalCount = mysql_fetch_array($totalCount);
    	$totalCount = (int)$totalCount['total_count'];


    } catch (FacebookApiException $e) {
        error_log($e);
        $user = null;
    }
}

?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

    <meta content="text/html; charset=utf-8" http-equiv="Content-Type"/>
    <meta name="author" content="Mushimu">
    <meta name="keywords" content="HTML, CSS, XML, XHTML, JavaScript, Facebook">
    <meta name="description" content="Break The Silence Facebook App">

    <script type="text/javascript" src='../js/jquery-2.0.3.min.js'></script>
    <!-- My flip counter script, REQUIRED -->
    <script type="text/javascript" src="../js/flipcounter.js"></script>
    <!-- Style sheet for the counter, REQUIRED -->
    <link rel="stylesheet" type="text/css" href="../css/counter.css" />

    <script type="text/javascript">


        $(document).ready(function () {
            var currentValueOfCounter = <?php echo $totalCount; ?>; //parseInt("<?php echo $totalCount; ?>");
	    var myCounter = new flipCounter('flip-counter', {value:currentValueOfCounter, inc:1, pace:600, auto:false});
            //var music = new Audio("sample.mp3");
            $("#audioUser").bind("ended", function () {
            	myCounter.step();
                userPlayEnd();
            });

            $("#audioCheer").bind("ended", function () {
                cheerPlayEnd();
            });

        });


        function showFrontLayer() {
            document.getElementById('bg_mask').style.visibility = 'visible';
            document.getElementById('frontlayer').style.visibility = 'visible';
        }
        function hideFrontLayer() {
            document.getElementById('bg_mask').style.visibility = 'hidden';
            document.getElementById('frontlayer').style.visibility = 'hidden';
        }

        function togglePlayPause() {
            var playpause = document.getElementById("playpause");
            var audio = document.getElementById("audioUser");
            // audio.addEventListener("ended", userPlayEnd);
            //audio.addEventListener("ended", function() {
            //  userPlayEnd();
            //  }, false);


            if (audio.paused || audio.ended) {
                playpause.title = "Playing voice for you";
                playpause.innerHTML = "Playing voice for you";        
                audio.play();
                playpause.disabled = true;
            } else {
                playpause.title = "play";
                playpause.innerHTML = "play";
                audio.pause();
            }
        }
        function userPlayEnd() {
            alert('increase count & cheer start');
            var audioCheer = document.getElementById("audioCheer");
            //audioCheer.addEventListener("ended", cheerPlayEnd);
            //audioCheer.addEventListener("ended", function() {
            //  cheerPlayEnd();
            // }, false);
                     
            $("#audianceImg").attr("src","../img/optimized_applause.gif");
            
            audioCheer.play();

            // animation start & counter ++
        }

        function cheerPlayEnd() {
            $("#audianceImg").attr("src","../img/optimized_applause-0.jpg");
            alert('change page');
            $.post('handleInvitation.php', {uid: <?php echo $id?>, status: 2 }, function (response) {
                window.top.location.href = "https://apps.facebook.com/breakthesilence/src/page/thankYouPage.php";
            });

        }

        //onended="userPlayEnd()" onended="cheerPlayEnd()"


    </script>

    <style type="text/css">

        #bg_mask {
            position: absolute;
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
            margin: auto;
            margin-top: 0px;
            width: 400px;
            height: 300px;
            background-color: red;
            z-index: 0;
            visibility: hidden;
        }

        #frontlayer {
            position: absolute;
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
        / / margin : 70 px 140 px 175 px 140 px;
            padding: 30px;
            width: 400px;
            height: 300px;
            background-color: pink;
            visibility: hidden;
            border: 1px solid black;
            z-index: 1;
        }
        
        .podiumFrameCenter {
	  margin: auto;
	  position: absolute;
	  top: 20%; 
	  left: 30%; 
	 // bottom: 50%; 
	 // right: 50%;
	}


    </style>

    <title>Podium Page</title>
</head>
<body onload="showFrontLayer();">

<div id="baselayer">
	
   <!-- <div id="controls">
        <button type="button" id="playpause" title="play" onclick="togglePlayPause()">Play</button>
    </div> -->
    
    <div id="podiumFrame" class="podiumFrameCenter">
    	<div id="wrapper"><div id="flip-counter" class="flip-counter"></div></div>
    	<img id="audianceImg" src="../img/optimized_applause-0.jpg" alt="Audiance" />
    	<!--<img src="../img/optimized_applause.gif" alt="Audiance Applause and cheering" />-->
    	<div style="width:100%;">
    		<button style="width:inherit;" type="button" id="playpause" title="play" onclick="togglePlayPause()">Play</button>
    	</div>
    </div>

    <audio id="audioUser" preload="auto">
        <source src="../img/userVoice.mp3" type="audio/mpeg"/>
    </audio>

    <audio id="audioCheer" preload="auto">
        <source src="../img/cheering.mp3" type="audio/mpeg"/>
    </audio>


    <div id="bg_mask">
        <div id="frontlayer"><br/><br/>
            Welcome to the app!! Raise your voice use senora :P !!
            <input type="button" value="Hide front layer" onclick="hideFrontLayer();"/>
        </div>
    </div>
</div>

</body>
</html>
CREATE TABLE bts_user (
  user_id        INT          NOT NULL AUTO_INCREMENT,
  fb_id          VARCHAR(100) NOT NULL,
  user_name      VARCHAR(100),
  gender         VARCHAR(8),
  date_of_birth  DATE,
  user_email     VARCHAR(50),
  user_location  VARCHAR(100),
  user_join_time DATETIME,
  phone_num      VARCHAR(30),
  is_delete      INT DEFAULT 0,
  PRIMARY KEY (user_id)
);

CREATE UNIQUE INDEX bts_user_fb_id_index ON bts_user (fb_id);


CREATE TABLE bts_userStat (
  user_id          INT          NOT NULL,
  fb_id            VARCHAR(100) NOT NULL,
  status           INT DEFAULT 0,
  no_of_share      INT DEFAULT 0,
  no_of_acceptance INT DEFAULT 0,
  PRIMARY KEY (user_id)
);

CREATE TRIGGER bts_userStat_insert
AFTER INSERT ON bts_user
FOR EACH ROW
  INSERT INTO bts_userStat (user_id, fb_id)
    VALUES (NEW.user_id, NEW.fb_id);

CREATE TABLE bts_info (
  table_id         INT DEFAULT 1,
  total_count      INT DEFAULT 0,
  cover_photo_path VARCHAR(100),
  PRIMARY KEY (table_id)
);

// FOR the FIRST TIME only
INSERT INTO bts_info (cover_photo_path)
VALUES (NULL);
<?php
/**
 * @author: imon
 * @since: 1/13/14 10:28 PM
 */

mysql_connect("localhost", "webstl_btsuser", "btsuser123") or die ("sorry Couldn't contact server !!!! try later !!!");
mysql_select_db("webstl_breakthesilence") or die ("sorry couldn't select DB !!! try again !!!");

?>
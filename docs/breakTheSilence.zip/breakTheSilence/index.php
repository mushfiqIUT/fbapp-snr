<?php
/**
 * @author: imon
 * @since: 1/12/14 7:28 PM
 */

header('P3P: CP="CAO PSA OUR"');
header('P3P: CP="HONK"');

$sitebasepath = $_SERVER['DOCUMENT_ROOT'];

require("$sitebasepath/breakTheSilence/src/process/authentication.php");


if ($user) {

    try {

        $likes_page = $facebook->api("/me/likes/1396002910653043/"); //page id for like 

        if (empty($likes_page['data'])) {
            ?>
            <script type="text/javascript">
                window.top.location.href = "https://apps.facebook.com/breakthesilence/src/page/likepage.php";
            </script>
            <?php
            //header('location: src/page/likepage.php');
        } else {

            $sql_getStatus = "SELECT status FROM bts_userStat WHERE fb_id = " . $id;
            $result_getStatus = mysql_query($sql_getStatus);
            $result_getStatus = mysql_fetch_array($result_getStatus);
            $statusValue = $result_getStatus['status'];

            if ($statusValue == 2) {
                ?>
                <script type="text/javascript">
                    window.top.location.href = "https://apps.facebook.com/breakthesilence/src/page/thankYouPage.php";
                </script>
                <?php
                //header('location: src/page/thankYouPage.php');
            } elseif ($statusValue == 0 || $statusValue == 1) {
                ?>
                <script type="text/javascript">
                    window.top.location.href = "https://apps.facebook.com/breakthesilence/src/page/podiumPage.php";
                </script>
                <?php
                //header('location: src/page/podiumPage.php');
            }
        }

    } catch (FacebookApiException $e) {
        error_log($e);
        $user = null;
    }


}


?>

<html>

<head>
    <title>Senora :: Home</title>
</head>

<body>
<?php
//header('location: http://facebook.appsbd.org/breakTheSilence/src/page/podiumPage.php');
/*echo 'This is a the test for senora appUser Id: ' . $id;
echo 'User name: ' . $name;
echo 'User gender: ' . $gender;
echo 'User birthday: ' . $birthday;
echo 'User email: ' . $email;
echo 'User location: ' . $location;
*/
?>
</body>

</html>